package cn.abc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cn.abc.model.User;

public class userdao {
	private Connection con;
	private String query;
	private PreparedStatement pst;
	private ResultSet rs;
	
	public userdao(Connection con) {
		this.con = con;
	}
	
	public User userLogin(String email , String pasword) {
		User user = null;
		try {
			query = "select * from user where email=? and password=?";
			pst=this.con.prepareStatement(query);
			pst.setString(1, email);
			pst.setString(2, pasword);
			rs = pst.executeQuery();
			
			if (rs.next()) {
				user = new User();
				user.setId(rs.getInt("id"));
				user.setName(rs.getString("name"));
				user.setEmail(email);
			}
		}catch(Exception e) {
			e.printStackTrace();
			System.out.print(e.getMessage());
		}
		return user;
	}


	public String insert(User newuser) throws SQLException {
		String result="data is entered";
		String query = "INSERT INTO user (name, email, password) VALUES (?, ?, ?)";
		PreparedStatement pst = this.con.prepareStatement(query);
		try {
	    pst.setString(1, newuser.getName());
	    pst.setString(2, newuser.getEmail());
	    pst.setString(3, newuser.getPassword());
	    pst.executeUpdate();
		}catch(SQLException e) {
			e.printStackTrace();
			result = "data is not entered";
		}
		return result;
	}

	
	
}
