package cn.abc.dao;

import cn.abc.model.Post;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PostDao {
    private Connection connection;

    public PostDao(Connection connection) {
        this.connection = connection;
    }

    // Method to create a new post
    public boolean createPost(Post post) {
        String sql = "INSERT INTO products (name, category, price, image) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, post.getName());
            pstmt.setString(2, post.getCategory());
            pstmt.setDouble(3, post.getPrice());
            pstmt.setString(4, post.getImage());
            return pstmt.executeUpdate() > 0; // Returns true if a row was inserted
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false if insertion fails
        }
    }

    // Method to get all posts from the database
    public List<Post> getAllPosts() {
        List<Post> posts = new ArrayList<>();
        String sql = "SELECT * FROM products"; // Adjust the SQL query if needed

        try (PreparedStatement pstmt = connection.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Post post = new Post();
                post.setId(rs.getInt("id")); // Assuming you have an ID field
                post.setName(rs.getString("name"));
                post.setCategory(rs.getString("category"));
                post.setPrice(rs.getDouble("price"));
                post.setImage(rs.getString("image")); // Adjust based on your column names
                posts.add(post); // Add the post to the list
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return posts; // Return the list of posts
    }
}
