package cn.abc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import cn.abc.model.Cart;
import cn.abc.model.Product;

public class ProductDao {
    private Connection connection;

    // Constructor accepting Connection
    public ProductDao(Connection connection) {
        this.connection = connection;
    }

    // Method to retrieve all products
    public List<Product> getAllProducts() throws SQLException {
        List<Product> products = new ArrayList<>();
        String query = "SELECT * FROM products"; // Ensure this matches your actual table name

        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                Product product = new Product();
                product.setId(resultSet.getInt("id"));
                product.setName(resultSet.getString("name"));
                product.setPrice(resultSet.getDouble("price"));
                product.setCategory(resultSet.getString("category"));
                product.setImage(resultSet.getString("image"));
                products.add(product);
            }
        }
        return products;
    }

    // Retrieve product by ID
    public Product getSingleProduct(int pId) {
        Product product = null;
        String query = "SELECT * FROM products WHERE id=?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, pId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                product = new Product();
                product.setId(resultSet.getInt("id"));
                product.setName(resultSet.getString("name"));
                product.setPrice(resultSet.getDouble("price"));
                product.setCategory(resultSet.getString("category"));
                product.setImage(resultSet.getString("image"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return product;
    }

    // Retrieve products in the cart
    public List<Cart> getCartProducts(ArrayList<Cart> cartList) {
        List<Cart> products = new ArrayList<>();
        String query = "SELECT * FROM products WHERE id=?";
        try {
            for (Cart item : cartList) {
                try (PreparedStatement statement = connection.prepareStatement(query)) {
                    statement.setInt(1, item.getProductId());
                    ResultSet resultSet = statement.executeQuery();
                    if (resultSet.next()) {
                        Cart cartProduct = new Cart();
                        cartProduct.setProductId(resultSet.getInt("id"));
                        cartProduct.setName(resultSet.getString("name"));
                        cartProduct.setCategory(resultSet.getString("category"));
                        cartProduct.setPrice(resultSet.getDouble("price"));
                        cartProduct.setQuantity(item.getQuantity());
                        products.add(cartProduct);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }

    // Calculate the total price for the cart
    public double getTotalCartPrice(ArrayList<Cart> cartList) {
        double total = 0;
        String query = "SELECT price FROM products WHERE id=?";
        try {
            for (Cart item : cartList) {
                try (PreparedStatement statement = connection.prepareStatement(query)) {
                    statement.setInt(1, item.getProductId());
                    ResultSet resultSet = statement.executeQuery();
                    if (resultSet.next()) {
                        total += resultSet.getDouble("price") * item.getQuantity();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return total;
    }
}
