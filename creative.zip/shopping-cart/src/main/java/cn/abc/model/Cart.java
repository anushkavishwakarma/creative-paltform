package cn.abc.model;

public class Cart extends Product {
	private int quantity;
	
	public Cart() {}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getProductId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setProductId(int int1) {
		// TODO Auto-generated method stub
		
	}
	
	
}
