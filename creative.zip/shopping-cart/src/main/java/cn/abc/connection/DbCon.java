package cn.abc.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbCon {
    public static Connection getConnection() throws SQLException {
        Connection connection = null;
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new SQLException("MySQL JDBC Driver not found.");
        }

        // Connection parameters
        String url = "jdbc:mysql://localhost:3306/ecommerce_mart";
        String user = "root"; // Your MySQL username
        String password = "root"; // Your MySQL password

        // Establish the connection
        connection = DriverManager.getConnection(url, user, password);
        return connection;
    }
}
