package cn.abc.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

@WebServlet("/chatbot")
public class ChatbotServlet extends HttpServlet {

    private static final String API_KEY = "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";
    private static final String API_URL = "https://api.openai.com/v1/chat/completions";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userMessage = request.getParameter("message");

        // Call the OpenAI API and get the response
        String botResponse = getAIResponse(userMessage);

        // Send the response back to the client
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.write("{\"response\": \"" + botResponse + "\"}");
        out.flush();
    }

    private String getAIResponse(String userMessage) {
        StringBuilder response = new StringBuilder();
        try {
            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + API_KEY);
            conn.setDoOutput(true);

            // JSON request body
            String jsonInputString = String.format("{\"model\": \"gpt-3.5-turbo\", \"messages\": [{\"role\": \"user\", \"content\": \"%s\"}]}", userMessage);

            // Send request
            conn.getOutputStream().write(jsonInputString.getBytes("UTF-8"));

            // Read response
            try (BufferedReader in = new BufferedReader(new java.io.InputStreamReader(conn.getInputStream()))) {
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
            }

            conn.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
            return "Sorry, I couldn't get a response.";
        }

        // Parse the response
        String responseBody = response.toString();
        return extractBotMessage(responseBody);
    }

    private String extractBotMessage(String jsonResponse) {
        // Simple extraction logic, you might want to use a JSON library for better parsing
        int start = jsonResponse.indexOf("\"content\":\"") + 12;
        int end = jsonResponse.indexOf("\"", start);
        return jsonResponse.substring(start, end).replace("\\n", "\n"); // Handle new lines
    }
}
