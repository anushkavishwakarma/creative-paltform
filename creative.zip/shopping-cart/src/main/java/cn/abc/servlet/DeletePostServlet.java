package cn.abc.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import cn.abc.connection.DbCon;
import cn.abc.dao.ProductDao;

@WebServlet("/DeletePostServlet")
public class DeletePostServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Retrieve the product ID from the request parameter
            String id = request.getParameter("id");
            if (id != null) {
                // Call the ProductDao to delete the product
                ProductDao productDao = new ProductDao(null);
                productDao.getSingleProduct(Integer.parseInt(id));
            }
            // Redirect to the admin page after deletion
            response.sendRedirect("admin.jsp");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("admin.jsp");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
