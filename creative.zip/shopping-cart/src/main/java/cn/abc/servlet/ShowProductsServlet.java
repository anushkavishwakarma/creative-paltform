package cn.abc.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import cn.abc.dao.PostDao;
import cn.abc.dao.ProductDao;
import cn.abc.model.Post;
import cn.abc.model.Product;
import cn.abc.connection.DbCon;

@WebServlet("/ShowProductsServlet")
public class ShowProductsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Fetch the product list from the database
        	ProductDao productDao = new ProductDao(null);
        	List<Product> products = productDao.getAllProducts();
        	request.setAttribute("products", products);
        	request.getRequestDispatcher("index.jsp").forward(request, response);



        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Unable to load products at this time. Please try again later.");
            request.getRequestDispatcher("createPost.jsp").forward(request, response);
        } catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
