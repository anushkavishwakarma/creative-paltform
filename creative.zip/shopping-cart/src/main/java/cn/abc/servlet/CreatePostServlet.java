package cn.abc.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import cn.abc.dao.PostDao;
import cn.abc.model.Post;
import cn.abc.connection.DbCon;

@WebServlet("/CreatePostServlet")
public class CreatePostServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Post> products = null; // Initialize products
        Connection con = null; // Initialize connection

        try {
            // Get database connection
            con = DbCon.getConnection();
            PostDao postDao = new PostDao(con); // Create a new instance of PostDao

            // Fetch all products
            products = postDao.getAllPosts(); // Get all products
            request.setAttribute("products", products); // Set products as request attribute

            // Forward to the JSP to display the product list
            request.getRequestDispatcher("createpost.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp?msg=Database error");
        } finally {
            if (con != null) {
                try {
                    con.close(); // Close the connection
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form parameters from JSP
        String name = request.getParameter("name");
        String category = request.getParameter("category");
        String image = request.getParameter("image");
        String priceStr = request.getParameter("price");

        // Validate inputs
        if (name == null || name.trim().isEmpty() ||
            category == null || category.trim().isEmpty() ||
            image == null || image.trim().isEmpty() ||
            priceStr == null || priceStr.trim().isEmpty()) {
            response.sendRedirect("error.jsp?msg=Invalid input");
            return;
        }

        // Parse price input
        double price;
        try {
            price = Double.parseDouble(priceStr);
        } catch (NumberFormatException e) {
            response.sendRedirect("error.jsp?msg=Invalid price format");
            return;
        }

        // Create a new Post object
        Post post = new Post();
        post.setName(name);
        post.setCategory(category);
        post.setImage(image);
        post.setPrice(price);

        Connection con = null;
        try {
            // Get database connection
            con = DbCon.getConnection();
            PostDao postDao = new PostDao(con);

            // Add the post to the database
            boolean result = postDao.createPost(post);

            // Fetch the updated list of posts after insertion
            List<Post> products = postDao.getAllPosts(); // Get all products after adding the new one
            request.setAttribute("products", products); // Set products as request attribute

            // Forward to the JSP with a success or failure message
            request.setAttribute("msg", result ? "Product added successfully" : "Failed to add product");
            request.getRequestDispatcher("createpost.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp?msg=Database error");
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
