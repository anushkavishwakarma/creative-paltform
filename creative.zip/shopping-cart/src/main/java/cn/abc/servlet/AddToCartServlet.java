package cn.abc.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import cn.abc.model.*;

/**
 * Servlet implementation class AddToCartServlet
 */
@WebServlet("/add-to-cart")
public class AddToCartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try {
            // Get product id from request
            int id = Integer.parseInt(request.getParameter("id"));

            // Create a new cart item with default quantity
            Cart cartItem = new Cart();
            cartItem.setId(id);
            cartItem.setQuantity(1);

            // Get the existing session or create a new one
            HttpSession session = request.getSession();

            // Retrieve the current cart list from session

            ArrayList<Cart> cartList = (ArrayList<Cart>) session.getAttribute("cart-list");

            // If the cart list is empty, create a new one
            if (cartList == null) {
                cartList = new ArrayList<>();
                cartList.add(cartItem);
                session.setAttribute("cart-list", cartList);
            } else {
                // Check if the product is already in the cart
                boolean itemExists = false;

                for (Cart item : cartList) {
                    if (item.getId() == id) {
                        item.setQuantity(item.getQuantity() + 1); // Increment quantity if item exists
                        itemExists = true;
                        break;
                    }
                }

                // If the item is not already in the cart, add it
                if (!itemExists) {
                    cartList.add(cartItem);
                }

                session.setAttribute("cart-list", cartList);
            }

            // Redirect to cart.jsp page
            response.sendRedirect("cart.jsp");

        } catch (NumberFormatException e) {
            response.getWriter().println("Invalid product ID.");
        }
    }
}
