package cn.abc.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import cn.abc.connection.DbCon;
import cn.abc.dao.userdao;
import cn.abc.model.User;

@WebServlet("/sign-up")
public class SignServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Redirect to the sign-up page
        response.sendRedirect("signup.jsp");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            // Retrieve form data
            String name = request.getParameter("sign-name");
            String email = request.getParameter("sign-email");
            String password = request.getParameter("sign-password");
            
            User newUser = new User(0, name, email, password, password);
            
            userdao udao = new userdao(DbCon.getConnection());
            String result = udao.insert(newUser);
            response.getWriter().print(result);
            request.getSession().setAttribute("auth",newUser); 	
			response.sendRedirect("index.jsp");
        } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    }

