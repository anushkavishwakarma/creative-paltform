package cn.abc.util;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.RequestDispatcher;

import java.io.IOException;

public class DispatcherUtil {

    // Method to forward the request to a specified JSP page
    public static void forward(HttpServletRequest request, HttpServletResponse response, String page) {
        RequestDispatcher dispatcher = request.getRequestDispatcher(page);  // No need to cast
        try {
            dispatcher.forward(request, response);
        } catch (ServletException | IOException e) {
            e.printStackTrace();
        }
    }

    // Optional: Method to redirect to a new page (can be used for external redirections)
    public static void redirect(HttpServletResponse response, String page) {
        try {
            response.sendRedirect(page);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
